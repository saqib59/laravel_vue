<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oDxkttEhE0e17cp7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/items' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Df80Z3XBEPX0kz0Z',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/item/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CA6CnSqs69b9esKd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/create_tag' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::albu4PPSwQCaDUyh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/get_tags' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8JXLUciawlqkCTud',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/edit_tag' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qbVJ23i0k4NTD3gj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/delete_tag' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cdVTe8C3MzDNqC4W',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b2WH8NCOZKI0UrNN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/delete_image' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7w789j1rAlhXL416',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/create_category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KWL6QAZCGe5SC7Qi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/get_categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mBqAlIZiUPD84I8g',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/edit_category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::r4Du6DPWHPbGFyvw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/delete_category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jbjovADL20sScbG7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/create_user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9sUfnkvHCt8PPUfb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/get_users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AwZtyqJTgZGxmr8C',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/edit_user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cFwAh1qbnI5IpLGv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/create_role' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JPhwpmyjfx9tuz7w',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/edit_role' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UbVkXayiOkfRiurZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/get_roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lHXbMtpftCEIN3wg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/assign_roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bSllmnlCIKIXeMEo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/add_design' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uLeWJzlfQf4LATrT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/admin_login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yqDjXPdIfnnbEXWl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4fnziyNHDSvZWY94',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog_data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7W5J6VxGSVn1eG0h',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JKBHyj3uIVTuKwQ4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/item/([^/]++)(?|(*:28))|/([^/]++)(*:45))/?$}sDu',
    ),
    3 => 
    array (
      28 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mYLfoyFdhpPvyAOf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::repFF7sdCnwDNvr5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      45 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1drP3zZRDx0qxYbY',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::oDxkttEhE0e17cp7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":289:{@S61oPcn048Hv2aWPx9B9l1zprsR+FvyKnxx8g9Ykwtc=.a:5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000221e6e93000000005893dde5";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::oDxkttEhE0e17cp7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Df80Z3XBEPX0kz0Z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/items',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ItemsController@index',
        'controller' => 'App\\Http\\Controllers\\ItemsController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Df80Z3XBEPX0kz0Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CA6CnSqs69b9esKd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/item/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ItemsController@store',
        'controller' => 'App\\Http\\Controllers\\ItemsController@store',
        'namespace' => NULL,
        'prefix' => 'api/item',
        'where' => 
        array (
        ),
        'as' => 'generated::CA6CnSqs69b9esKd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mYLfoyFdhpPvyAOf' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/item/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ItemsController@update',
        'controller' => 'App\\Http\\Controllers\\ItemsController@update',
        'namespace' => NULL,
        'prefix' => 'api/item',
        'where' => 
        array (
        ),
        'as' => 'generated::mYLfoyFdhpPvyAOf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::repFF7sdCnwDNvr5' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/item/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ItemsController@destroy',
        'controller' => 'App\\Http\\Controllers\\ItemsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/item',
        'where' => 
        array (
        ),
        'as' => 'generated::repFF7sdCnwDNvr5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::albu4PPSwQCaDUyh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/create_tag',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@addTag',
        'controller' => 'App\\Http\\Controllers\\AdminController@addTag',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::albu4PPSwQCaDUyh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8JXLUciawlqkCTud' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/get_tags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@getTags',
        'controller' => 'App\\Http\\Controllers\\AdminController@getTags',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::8JXLUciawlqkCTud',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qbVJ23i0k4NTD3gj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/edit_tag',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@editTag',
        'controller' => 'App\\Http\\Controllers\\AdminController@editTag',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::qbVJ23i0k4NTD3gj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::cdVTe8C3MzDNqC4W' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/delete_tag',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@deleteTag',
        'controller' => 'App\\Http\\Controllers\\AdminController@deleteTag',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::cdVTe8C3MzDNqC4W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::b2WH8NCOZKI0UrNN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@upload',
        'controller' => 'App\\Http\\Controllers\\AdminController@upload',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::b2WH8NCOZKI0UrNN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7w789j1rAlhXL416' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/delete_image',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@deleteImage',
        'controller' => 'App\\Http\\Controllers\\AdminController@deleteImage',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::7w789j1rAlhXL416',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KWL6QAZCGe5SC7Qi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/create_category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@createCategory',
        'controller' => 'App\\Http\\Controllers\\AdminController@createCategory',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::KWL6QAZCGe5SC7Qi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mBqAlIZiUPD84I8g' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/get_categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@getCategories',
        'controller' => 'App\\Http\\Controllers\\AdminController@getCategories',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::mBqAlIZiUPD84I8g',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::r4Du6DPWHPbGFyvw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/edit_category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@editCategory',
        'controller' => 'App\\Http\\Controllers\\AdminController@editCategory',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::r4Du6DPWHPbGFyvw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jbjovADL20sScbG7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/delete_category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@deleteCategory',
        'controller' => 'App\\Http\\Controllers\\AdminController@deleteCategory',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::jbjovADL20sScbG7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9sUfnkvHCt8PPUfb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/create_user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@createUser',
        'controller' => 'App\\Http\\Controllers\\AdminController@createUser',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::9sUfnkvHCt8PPUfb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AwZtyqJTgZGxmr8C' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/get_users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@getUsers',
        'controller' => 'App\\Http\\Controllers\\AdminController@getUsers',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::AwZtyqJTgZGxmr8C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::cFwAh1qbnI5IpLGv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/edit_user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@editUser',
        'controller' => 'App\\Http\\Controllers\\AdminController@editUser',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::cFwAh1qbnI5IpLGv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::JPhwpmyjfx9tuz7w' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/create_role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@createRole',
        'controller' => 'App\\Http\\Controllers\\AdminController@createRole',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::JPhwpmyjfx9tuz7w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UbVkXayiOkfRiurZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/edit_role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@editRole',
        'controller' => 'App\\Http\\Controllers\\AdminController@editRole',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::UbVkXayiOkfRiurZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lHXbMtpftCEIN3wg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/get_roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@getRoles',
        'controller' => 'App\\Http\\Controllers\\AdminController@getRoles',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::lHXbMtpftCEIN3wg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bSllmnlCIKIXeMEo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/assign_roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@assignRoles',
        'controller' => 'App\\Http\\Controllers\\AdminController@assignRoles',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::bSllmnlCIKIXeMEo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uLeWJzlfQf4LATrT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/add_design',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@addDesign',
        'controller' => 'App\\Http\\Controllers\\AdminController@addDesign',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::uLeWJzlfQf4LATrT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yqDjXPdIfnnbEXWl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/admin_login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\AdminCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@adminLogin',
        'controller' => 'App\\Http\\Controllers\\AdminController@adminLogin',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
        'as' => 'generated::yqDjXPdIfnnbEXWl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4fnziyNHDSvZWY94' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@index',
        'controller' => 'App\\Http\\Controllers\\AdminController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::4fnziyNHDSvZWY94',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7W5J6VxGSVn1eG0h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog_data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@designListing',
        'controller' => 'App\\Http\\Controllers\\AdminController@designListing',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::7W5J6VxGSVn1eG0h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::JKBHyj3uIVTuKwQ4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@logout',
        'controller' => 'App\\Http\\Controllers\\AdminController@logout',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::JKBHyj3uIVTuKwQ4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1drP3zZRDx0qxYbY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => '{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@index',
        'controller' => 'App\\Http\\Controllers\\AdminController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::1drP3zZRDx0qxYbY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
