<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <!-- Fonts -->
    <link rel="stylesheet" type="text/css" href="/css/all.css">    
    <script>
        window.Laravel = {
            user : <?php echo auth()->user() ?? 'false'; ?>,
            permission : <?php echo auth()->user()->role->permissions ?? 'false'; ?>

        }
    </script>
    <script type="text/javascript" src="<?php echo e(mix('js/app.js')); ?>" defer></script>    
     </head>
    <body>
        <div id="app">
            
        </div>
    </body>
</html>
<?php /**PATH /var/www/html/Saqib/laravel/resources/views//welcome.blade.php ENDPATH**/ ?>